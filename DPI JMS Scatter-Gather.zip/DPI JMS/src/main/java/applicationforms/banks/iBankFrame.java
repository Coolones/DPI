package applicationforms.banks;

import mix.model.bank.BankInterestRequest;

public interface iBankFrame {

    void Add(BankInterestRequest request);
}
